import SignupRouter from './signUp';
import SigninRouter from './signIn';
import EventRouter from './event';
import ElectionRouter from './election';
import BallotRouter from './ballot';
import VotersRouter from './voters';
import VotingRouter from './voting';
import ResultRouter from './result';

export default {
	SignupRouter,
	SigninRouter,
	EventRouter,
	ElectionRouter,
	BallotRouter,
	VotersRouter,
	VotingRouter,
	ResultRouter,
};
