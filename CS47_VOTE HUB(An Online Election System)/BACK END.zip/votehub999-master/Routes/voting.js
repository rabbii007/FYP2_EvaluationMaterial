import express from 'express';
import voting from '../Controllers/voting';
// auth middleware for user
import isLoggedInUser from '../Middlewares/loggedIn';


const votingRouter = express.Router();


votingRouter.post('/', isLoggedInUser.isLoggedIn, voting.sendlink);
votingRouter.post('/getcandidates',  voting.getcandidates);
votingRouter.post('/verify',  voting.verify);
votingRouter.post('/verify2',  voting.verify2);
votingRouter.post('/test',  voting.test);


export default votingRouter;
