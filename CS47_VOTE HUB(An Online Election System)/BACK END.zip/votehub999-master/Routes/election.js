import express from 'express';
import election from '../Controllers/election';
// auth middleware for user
import isLoggedInUser from '../Middlewares/loggedIn';


const electionRouter = express.Router();

electionRouter.post(
	'/add',
	isLoggedInUser.isLoggedIn,
	election.addElection,
);

electionRouter.get('/', isLoggedInUser.isLoggedIn, election.getElection);


export default electionRouter;
