import express from 'express';
import ballot from '../Controllers/ballot';
// auth middleware for user
import isLoggedInUser from '../Middlewares/loggedIn';


const ballotRouter = express.Router();

ballotRouter.post(
	'/create',
	isLoggedInUser.isLoggedIn,
	ballot.createBallot,
);

ballotRouter.get('/', isLoggedInUser.isLoggedIn, ballot.getBallot);


export default ballotRouter
