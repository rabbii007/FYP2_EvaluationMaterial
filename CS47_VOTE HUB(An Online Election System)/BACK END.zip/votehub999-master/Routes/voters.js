import express from 'express';
import voters from '../Controllers/voters';
// auth middleware for user
import isLoggedInUser from '../Middlewares/loggedIn';


const votersRouter = express.Router();

votersRouter.post(
	'/add',
	isLoggedInUser.isLoggedIn,
	voters.addVoters,
);

votersRouter.post('/', isLoggedInUser.isLoggedIn, voters.getVoters);


export default votersRouter;
