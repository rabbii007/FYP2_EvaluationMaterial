import express from 'express';
import result from '../Controllers/result';



const resultRouter = express.Router();

resultRouter.post('/',  result.selection);
resultRouter.post('/show',  result.getResult);


export default resultRouter;
