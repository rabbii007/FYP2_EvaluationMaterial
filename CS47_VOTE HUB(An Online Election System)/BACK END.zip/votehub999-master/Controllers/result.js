import bcryptjs from 'bcryptjs';
import Model from '../Models/Model';
import awsHandler from './aws';
import status from 'http-status';

var nodeMailer = require('nodemailer');

const selection = (req, res, next) => {

const { title, selection , accessKey} = req.body;

	
					const addVoters = new Model.ResultModel({
						
						title,
                        selection,
                        accessKey,
						
						
					});

					addVoters.save()
						.then(SavedDoc => {
							console.log(SavedDoc);
							return res.status(200).send({
								Message: 'Request Made Successfully.',
							});
						})
						// eslint-disable-next-line no-unused-vars
						.catch(err => {
							res.status(500);
							next(new Error('Unable to Create Request. Please Try later.'));
						});
				
};

const getResult = (req, res) => {

    let array = [];

     Model.VotersModel.find({ title: req.body.title })
		.then(events => {
            const voterlist = events[0].voterEmail.length;
            
            Model.ResultModel.find({ title: req.body.title })
		.then(events => {
            const votescount = events.length
           
            events.map(sensor => {
            array.push(sensor.selection);
            })
           
            
                  const array2 = array.map(function(v) {
                  return v[0];
                  })
                   console.log(array2)


            res.send(array2)
		})
		.catch(err => {
			res.status(status.INTERNAL_SERVER_ERROR).send({
				Message: 'No Requests!',
				err,
			});
		});


		})
		.catch(err => {
			res.status(status.INTERNAL_SERVER_ERROR).send({
				Message: 'No Requests!',
				err,
			});
		});

};

export default {selection, getResult};
