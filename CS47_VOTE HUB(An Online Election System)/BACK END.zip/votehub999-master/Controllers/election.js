import status from 'http-status';

import bcryptjs from 'bcryptjs';
import Model from '../Models/Model';

    
const addElection = (req, res, next) => {
   const {  title, organization, startdate, enddate} = req.body;

	
					const addelection = new Model.ElectionModel({
						userId:req.user._id,
                        title,
						organization,
						startdate,
						enddate,
						
					});

					addelection.save()
						.then(SavedDoc => {
							console.log(SavedDoc);
							return res.status(200).send({
								Message: 'Request Made Successfully.',
							});
						})
						// eslint-disable-next-line no-unused-vars
						.catch(err => {
							res.status(500);
							next(new Error('Unable to Create Request. Please Try later.'));
						});
				
};

const getElection = (req, res) => {
	Model.ElectionModel.find({ userId: req.user._id })
		.then(events => {
			res.status(status.OK).send(events);
		})
		.catch(err => {
			res.status(status.INTERNAL_SERVER_ERROR).send({
				Message: 'No Requests!',
				err,
			});
		});
};

export default {addElection, getElection};
