import status from 'http-status';

import bcryptjs from 'bcryptjs';
import Model from '../Models/Model';

    
const addVoters = (req, res, next) => {
   const { title, voterId, voterEmail, voterNo} = req.body;

	
					const addVoters = new Model.VotersModel({
						userId:req.user._id,
						title,
                        voterId,
						voterEmail,
						voterNo,
						
					});

					addVoters.save()
						.then(SavedDoc => {
							console.log(SavedDoc);
							return res.status(200).send({
								Message: 'Request Made Successfully.',
							});
						})
						// eslint-disable-next-line no-unused-vars
						.catch(err => {
							res.status(500);
							next(new Error('Unable to Create Request. Please Try later.'));
						});
				
};

const getVoters = (req, res) => {
	console.log(req.body)
	Model.VotersModel.find({ userId: req.user._id,  title:req.body.title})
		.then(events => {
			res.status(status.OK).send(events);
		})
		.catch(err => {
			res.status(status.INTERNAL_SERVER_ERROR).send({
				Message: 'No Requests!',
				err,
			});
		});
};



export default {addVoters, getVoters};
