import bcryptjs from 'bcryptjs';
import Model from '../Models/Model';
import awsHandler from './aws';
var nodeMailer = require('nodemailer');

const userSignUp = (req, res, next) => {
const { firstname,lastname, password, email, organizationType,organizationName,organizationLocation,voterlistSize } = req.body;
	var hostname= "localhost";
	var link = "Election-site.herokuapp.com/login";

				const query = { email };

				Model.UserModel.findOne(query)
					.then((user) => {
						if (user) {
							if (user.email == email) {
								res.status(400);
								next(new Error('Email Already Taken.'));
							}
						} else {
							bcryptjs.hash(password, 12).then((hashedpassword) => {
								const User = new Model.UserModel({ 
									firstname,
									lastname,
									password: hashedpassword,
									email,
									organizationType,
									organizationName,
									organizationLocation,
									voterlistSize
								});
								// console.log(User);
								User.save()
									.then((SavedUser) => {
										let transporter = nodeMailer.createTransport({
    host: "smtp.gmail.com",
    secureConnection: false,
    port: 587,
    tls: {
        chipers: "SSLv3"
    },
    auth: {
        user: "votehub999@gmail.com",
        pass: "ucwsagnxmobtnlcs"
    }
});

var mailOptions = {
    from: "votehub999@gmail.com",
    to: email,
    subject: " Account Verification ....!!!",
    //text: "The calculated estimate for you order is " + est + "If you want to continue then click on this link",
	html: `Verify your Account... If you want to continue then click on this link  ${link}`,
	
};

transporter.sendMail(mailOptions, function(error, info) {
    if (error) console.log(error);
    else console.log("Message sent successfully: " + info.response);
})
										console.log(SavedUser);
										return res.status(200).send({
											Message: 'Account Created Successfully.',
											SavedUser,
										});
									})
									.catch((err) => {
										res.status(500);
										next(
											new Error(
												`Unable to Create User. Please Try later. ${err}`,
											),
										);
									});
							});
						}
					})
					.catch((err) => {
						res.status(500);
						next(new Error(err));
					});
			
	 
};

const editStatus = (req, res) => {
	console.log(req.body.email)
	    Model.UserModel.findOneAndUpdate({email: req.body.email},{$set:{emailStatus:"Verified"}})   
        .then((docs)=>{
    if(docs) {
       res.send("updated")
    } else {
       res.send("no data found")
    }
}).catch((err)=>{
  res.send(error)
})
} 

export default {userSignUp, editStatus};
