import status from 'http-status';

import bcryptjs from 'bcryptjs';
import Model from '../Models/Model';

    
const createBallot = (req, res, next) => {
   const {  electiontitle, ballotInfo, noVacancy, noCandidates, position, candidatename, description, instructions} = req.body;
console.log(req.body)
	
					const createBallot = new Model.BallotModel({
						userId:req.user._id,
                        electiontitle,
						ballotInfo,
						noVacancy,
						noCandidates,
						details:{
                        position,
                        candidatename,
                        description,
						},
						 instructions,
					});

					createBallot.save()
						.then(SavedDoc => {
							console.log(SavedDoc);
							return res.status(200).send({
								Message: 'Request Made Successfully.',
                                SavedDoc,
							});
						})
						// eslint-disable-next-line no-unused-vars
						.catch(err => {
							res.status(500);
							//console.log(err)
							next(new Error('Unable to Create Request. Please Try later.'));
						});
				
};

const getBallot = (req, res) => {
	Model.BallotModel.find({ userId: req.user._id })
		.then(events => {
			res.status(status.OK).send(events);
		})
		.catch(err => {
			res.status(status.INTERNAL_SERVER_ERROR).send({
				Message: 'No Requests!',
				err,
			});
		});
};

export default {createBallot, getBallot};
