import bcryptjs from 'bcryptjs';
import Model from '../Models/Model';
import awsHandler from './aws';
import status from 'http-status';
const Nexmo = require('nexmo')
var nodeMailer = require('nodemailer');
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
var clockwork = require('clockwork')({key:'7c51a0935d8a08b3dc10aff9967589b50e5ab836'});

const accountSid = 'ACe201851760b8759e3e0339e9712724ad';
const authToken = 'c6318a4f56a7807af709956f7b532c62';
const client = require('twilio')(accountSid, authToken);

const sendlink = (req, res, next) => {

const { title } = req.body;

	var hostname= "localhost";
	var link = "Election-site.herokuapp.com/user/new-election/voting?title="+req.body.title;


				
         Model.VotersModel.find({ userId: req.user._id,  title:req.body.title})
		.then(events => {
            

            const emails = events[0].voterEmail;
			const number = events[0].voterNo;
            
            for (var i=0;i<emails.length;i++){
                console.log(emails[i])
				var num = Math.floor(Math.random()*100000);

					client.messages
					.create({
						body: num,
						from: '+1 267 310 3457',
						to: number[i]
						})
						.then(message => 
						console.log(message.sid)
						//res.send(message.sid)
						);

				let transporter = nodeMailer.createTransport({
					host: "smtp.gmail.com",
					secureConnection: false,
					port: 587,
					tls: {
						chipers: "SSLv3"
						},
						auth: {
							user: "votehub999@gmail.com",
							pass: "ucwsagnxmobtnlcs"
							}
							});
							
					var mailOptions = {
						from: "votehub999@gmail.com",
						to: emails[i],
						subject: " Voting Request ....!!!",
						html: `You have received Voting Request.... Find your AccessKey in message you recieved ... If you want to Vote then click on this link  ${link}`,
						};
						
					transporter.sendMail(mailOptions, function(error, info) {
						if (error) console.log(error);
						else console.log("Message sent successfully: " + info.response);
						})
						

						const addVoters = new Model.VoterlistModel({
						userId:req.user._id,
						title,
						voterEmail:emails[i],
						voterNo:number[i],
						accessKey:num,
						
					});

					addVoters.save()
						.then(SavedDoc => {
							console.log(SavedDoc);
							// return res.status(200).send({
							// 	Message: 'Request Made Successfully.',
							// });
						})
						// eslint-disable-next-line no-unused-vars
						.catch(err => {
							res.status(500);
							next(new Error('Unable to Create Request. Please Try later.'));
						});
						
						}
						res.status(status.OK).send(events);
						
						})
						.catch(err => {
							res.status(status.INTERNAL_SERVER_ERROR).send({
								Message: 'No Requests!',
								err,
								});
								});
								
};

const verify = (req, res) => {
	console.log(req.body)

Model.VoterlistModel.find({ title:req.body.title ,  accessKey: req.body.accessKey })
		.then(events => {
            console.log(events.length)
			if(events.length==0){
				res.status(status.OK).send("No Access Key Found");
			}
			else{

				Model.ResultModel.find({ title: req.body.title , accessKey: req.body.accessKey })
		.then(events2 => {
            console.log(events2)
			if(events2.length==0){
				res.status(status.OK).send("Key Matched.. You can vote now");

			}
			else{
			res.status(status.OK).send("You have already voted");
			}
		})
		.catch(err => {
			res.status(status.INTERNAL_SERVER_ERROR).send({
				Message: 'No Requests!',
				err,
			});
		});

			//res.status(status.OK).send(events);
			}
		})
		.catch(err => {
			res.status(status.INTERNAL_SERVER_ERROR).send({
				Message: 'No Requests!',
				err,
			});
		});
			
};

const verify2 = (req, res) => {
	console.log(req.body)

Model.VoterlistModel.find({ accessKey: req.body.accessKey })
		.then(events => {
            console.log(events.length)
			if(events.length==0){
				res.status(status.OK).send("No Access Key Found");
			}
			else{
				const title2 = events[0].title;


				Model.ResultModel.find({ title: title2 , accessKey: req.body.accessKey })
		.then(events2 => {
            console.log(events2)
			if(events2.length==0){
				res.status(status.OK).send(title2);

			}
			else{
			res.status(status.OK).send("You have already voted");
			}
		})
		.catch(err => {
			res.status(status.INTERNAL_SERVER_ERROR).send({
				Message: 'No Requests!',
				err,
			});
		});

			//res.status(status.OK).send(events);
			}
		})
		.catch(err => {
			res.status(status.INTERNAL_SERVER_ERROR).send({
				Message: 'No Requests!',
				err,
			});
		});
			
};

const getcandidates = (req, res) => {
	console.log(req.body)
Model.BallotModel.find({ electiontitle: req.body.title })
		.then(events => {
            console.log(events[0].details[0].candidatename)
			res.status(status.OK).send(events[0].details[0].candidatename);
		})
		.catch(err => {
			res.status(status.INTERNAL_SERVER_ERROR).send({
				Message: 'No Requests!',
				err,
			});
		});
			
};
const test = (req, res) => {
	client.messages
  .create({
     body: 'heelloooo?',
     from: '+1 267 310 3457',
     to: '+923361545206'
   })
  .then(message => 
  //console.log(message.sid);
  res.send(message.sid)
  );
	
};

export default {sendlink, getcandidates, verify, verify2 , test};
