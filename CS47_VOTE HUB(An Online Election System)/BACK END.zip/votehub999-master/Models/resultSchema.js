const mongoose = require('mongoose');

const resultSchema = new mongoose.Schema(
	{
        
		title: { 
            type: String, ref: 'elections'
            },
        accessKey: { 
            type: String,
            },
		selection: [],
		
	},
	
);

export default mongoose.model('Result', resultSchema);
