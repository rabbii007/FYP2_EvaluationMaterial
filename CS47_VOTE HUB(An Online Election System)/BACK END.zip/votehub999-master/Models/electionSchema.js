const mongoose = require('mongoose');

const electionSchema = new mongoose.Schema(
	{
        userId: { 
            type: mongoose.Schema.Types.ObjectId, ref: 'users'
            },
		title: {
			type: String,
			required: true,
		},
		organization: {
			type: String,
			required: true,
		},
		startdate: {
			type: String,
		},
		enddate: {
			type: String,
		},
		
	},
	{
		timestamps: true,
	},
);

export default mongoose.model('Election', electionSchema);
