const mongoose = require('mongoose');

const ballotSchema = new mongoose.Schema(
	{
        userId: { 
            type: mongoose.Schema.Types.ObjectId, ref: 'users'
            },
		electiontitle: {
			type: String,
			ref: 'elections'
		},
		ballotInfo: {
			type: String,
			required: true,
		},
		noVacancy: {
			type: String,
            required: true,
		},
		noCandidates: {
			type: String,
            required: true,
		},
        details: [
			{
				position: {
					type: String,
					required: true,
				},
				candidatename: [
					// type: String,
					// required: true,
				],
                description: [
					// type: String,
					// required: true,
				],
			
			},
		],
        instructions: {
			type: String,
			required: true,
		},
		
	},
	{
		timestamps: true,
	},
);

export default mongoose.model('Ballot', ballotSchema);
