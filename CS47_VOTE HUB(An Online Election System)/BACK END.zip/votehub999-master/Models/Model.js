import UserModel from './userSchema';
import EventModel from './eventSchema';
import ElectionModel from './electionSchema';
import BallotModel from './ballotSchema';
import VotersModel from './votersSchema';
import VoterlistModel from './voterlistSchema';
import ResultModel from './resultSchema';

export default {
	UserModel,
	EventModel,
	ElectionModel,
	BallotModel,
	VotersModel,
	ResultModel,
	VoterlistModel,
};
