const mongoose = require('mongoose');

const voterlistSchema = new mongoose.Schema(
	{
        userId: { 
            type: mongoose.Schema.Types.ObjectId, ref: 'users'
            },
		title: { 
            type: String, ref: 'elections'
            },
		
		voterEmail: {
			type: String,
        },
		voterNo: {
			 type: String,
        },
        accessKey: {
			 type: String,
        },
		
	},
	
);

export default mongoose.model('Voterlist', voterlistSchema);
