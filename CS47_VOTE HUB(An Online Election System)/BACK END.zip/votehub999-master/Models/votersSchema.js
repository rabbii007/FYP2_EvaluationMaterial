const mongoose = require('mongoose');

const votersSchema = new mongoose.Schema(
	{
        userId: { 
            type: mongoose.Schema.Types.ObjectId, ref: 'users'
            },
		title: { 
            type: String, ref: 'elections'
            },
		voterId: [
			// type: String,
			// ref: 'elections'
		],
		voterEmail: [
			// type: String,
			// required: true,
		],
		voterNo: [
			// type: String,
            // required: true,
		],
		
	},
	
);

export default mongoose.model('Voters', votersSchema);
