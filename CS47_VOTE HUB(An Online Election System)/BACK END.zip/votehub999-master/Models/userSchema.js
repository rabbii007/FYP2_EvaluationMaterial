const mongoose = require('mongoose');

const userSchema = new mongoose.Schema(
	{
		firstname: {
			type: String,
			required: true,
		},
		lastname: {
			type: String,
			required: true,
		},
		password: {
			type: String,
		},
		email: {
			type: String,
		},
		emailStatus: {
			type: String,
			default: "Not Verified",
		},
		organizationType: {
			type: String,
		},
		organizationName: {
			type: String,
		},
		organizationLocation: {
			type: String,
		},
		voterlistSize: {
			type: String,
		},
	},
	
);

export default mongoose.model('User', userSchema);
